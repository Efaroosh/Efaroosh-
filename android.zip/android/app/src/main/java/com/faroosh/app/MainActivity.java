package com.faroosh.app;
import io.flutter.embedding.android.FlutterActivity;
public class MainActivity extends FlutterActivity {}
