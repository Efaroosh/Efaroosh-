import 'package:flutter/material.dart';
void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(title: Text("Faroosh Super App")),
      body: Center(child: Text("Welcome to Faroosh!")),
    ),
  ));
}
